#pragma once
#include <ArduinoBLE.h>

#define print_log(msg) Serial.println(msg); Serial.flush(); delay(20);

// Keep your UUID family (matches what you used before)
static const char* SERVICE_UUID = "2d0a0000-e0f7-5fc8-b50f-05e267afeb66";
static const char* PRED_UUID    = "2d0a0001-e0f7-5fc8-b50f-05e267afeb67"; // notify
static const char* RX_UUID      = "2d0a0002-e0f7-5fc8-b50f-05e267afeb68"; // optional write

BLEService service(SERVICE_UUID);

// Send prediction as uint16 (cmd 1..5)
BLEUnsignedShortCharacteristic predChar(PRED_UUID, BLERead | BLENotify);

// Optional RX (if you want commands later)
BLEByteCharacteristic rxChar(RX_UUID, BLERead | BLEWrite);

class Blue {
public:
  void begin(const char* localName) {
    print_log("BLE (peripheral) init..");

    while (!BLE.begin()) {
      print_log("BLE.begin() failed, retrying...");
      delay(200);
    }

    BLE.setLocalName(localName);
    BLE.setAdvertisedService(service);

    service.addCharacteristic(predChar);
    service.addCharacteristic(rxChar);
    BLE.addService(service);

    // Default value
    predChar.writeValue((unsigned short)0);

    rxChar.setEventHandler(BLEWritten, [](BLEDevice central, BLECharacteristic c) {
      (void)c;
      uint8_t v = rxChar.value();
      Serial.print("[Nicla] RX wrote: ");
      Serial.println((int)v);
    });

    BLE.advertise();
    Serial.print("[Nicla] Advertising as: ");
    Serial.println(localName);
    Serial.print("[Nicla] Service UUID: ");
    Serial.println(SERVICE_UUID);
    Serial.print("[Nicla] Pred Char UUID: ");
    Serial.println(PRED_UUID);

    print_log("BLE init OK");
  }

  void poll() {
    BLE.poll();

    BLEDevice central = BLE.central();
    if (central) {
      if (!_hadCentral) {
        _hadCentral = true;
        Serial.print("[Nicla] Central connected: ");
        Serial.println(central.address());
      }
      if (!central.connected() && _hadCentral) {
        _hadCentral = false;
        Serial.println("[Nicla] Central disconnected");
        // keep advertising (ArduinoBLE usually continues, but we can be explicit)
        BLE.advertise();
        Serial.println("[Nicla] Advertising restarted");
      }
    }
  }

  bool connected() {
    BLEDevice central = BLE.central();
    return central && central.connected();
  }

  void sendCmdU16(uint16_t cmd) {
    // cmd is 1..5
    predChar.writeValue((unsigned short)cmd);

    Serial.print("[Nicla] Notify cmd=");
    Serial.print(cmd);
    Serial.print(" (connected=");
    Serial.print(connected() ? "yes" : "no");
    Serial.println(")");
  }

private:
  bool _hadCentral = false;
};
