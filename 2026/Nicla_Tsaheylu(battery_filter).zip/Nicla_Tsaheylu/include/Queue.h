#pragma once

/**
 * Arrange data into windows
 */
class Queue {
  public:
    signal_t sig;
    float data[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];

    Queue() {
      i = 0;
      _shiftPercent = 0.25;
    }

    /**
     * Test if window is full and ready for prediction
     */
    bool isReady() {
      return i == EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE;
    }

    /**
     * 
     */
    void addSample(float ax, float ay, float az) {
      if (isReady())
        shift();
        
      data[i++] = ax;
      data[i++] = ay;
      data[i++] = az;
    }

    /**
     * Convert array to EI signal_t
     */
    void toSignal() {
      numpy::signal_from_buffer(data, EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, &sig);
    }

    /**
     * Set shift
     */
    void shiftPercent(float percent) {
      _shiftPercent = percent;
    }

  protected:
    size_t i;
    float _shiftPercent;

    /**
     * Make room for new data
     */
    void shift() {
      const size_t shiftSamples = EI_CLASSIFIER_RAW_SAMPLE_COUNT * _shiftPercent;
      const size_t shiftCount = shiftSamples * EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME;

      memcpy(data, data + shiftCount, sizeof(float) * (EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE - shiftCount));
      i -= shiftCount;
    }
};
