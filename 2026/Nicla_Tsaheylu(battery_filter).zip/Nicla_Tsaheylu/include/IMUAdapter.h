#pragma once

/**
 * Since I only have a Nano BLE Sense, this file
 * allows me to test on my hardware and you to run
 * on your Nicla Sense ME
 */
#define print_log(msg) Serial.println(msg); Serial.flush(); delay(100);

#ifdef ARDUINO_ARDUINO_NANO33BLE

#include <Arduino_LSM9DS1.h>


class IMUAdapter {
  public:
    float ax, ay, az;
    
    /**
     * Init sensor
     */
    void begin() {
      print_log("IMU begin...");
      
      if (!IMU.begin()) {
        print_log("ERROR");
        begin();
      }

      print_log("IMU begin OK");
    }

    void read() {
      while (!IMU.accelerationAvailable())
        delay(1);

      IMU.readAcceleration(ax, ay, az);
    }
};

#else

#include <Nicla_System.h>
#include <Arduino_BHY2.h>
#define CONVERT_G_TO_MS2 9.80665f


class IMUAdapter {
  public:
    float ax, ay, az;

    IMUAdapter() : acc(SENSOR_ID_ACC) {
      
    }
    
    /**
     * Init sensor
     */
    bool begin() {
      delay(100);

      if (!nicla::begin()) {
        print_log("nicla::begin() failed");
        return false;
      }

      print_log("nicla::begin() succeded");
      
      if (!BHY2.begin(NICLA_I2C)) {
        print_log("BHY2.begin(NICLA_I2C) failed");
        return false;
      }

      print_log("BHY2.begin(NICLA_I2C) succeded");

      // DogMoveData is sampled at 100 Hz
      if (!acc.begin(100)) {
        print_log("acc.begin(100) failed");
        return false;
      }

      print_log("acc.begin(100) succeded");

      // adjust accelerometer parameters here

      return true;
    }

    void read() {
      BHY2.update();
      ax = acc.x();
      ay = acc.y();
      az = acc.z();

      // convert to ms2
      ax = (ax * 8.0 / 32768.0) * CONVERT_G_TO_MS2;
      ay = (ay * 8.0 / 32768.0) * CONVERT_G_TO_MS2;
      az = (az * 8.0 / 32768.0) * CONVERT_G_TO_MS2;
    }
    
  protected:
    SensorXYZ acc;
};

#endif
