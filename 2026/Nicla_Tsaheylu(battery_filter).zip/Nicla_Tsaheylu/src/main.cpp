#define BLE_NAME "NiclaCoba"   // keep ASCII for now (safer for BLE scanners)

#include "./IMUAdapter.h"
#include "./DogChain.h"
#include "./Blue.h"
#include "Nicla_System.h"              // Nicla library to be able to enable battery charging and LED control

Blue bluet;
IMUAdapter imu;
tinyml4all::DogChain chain;

static const char* labels[] = {"Sitting", "Sniffing", "Standing", "Trotting", "Walking"};

// -------------------- Hysteresis / dwell config --------------------
// Index = class idx (0..4)
static const uint32_t kDwellMs[5] = {
  1400, // 0 Sitting  (longest: very stable)
  800,  // 1 Sniffing (often noisy; keep it a bit conservative)
  1100, // 2 Standing (stable)
  550,  // 3 Trotting (active -> more responsive)
  650   // 4 Walking  (active -> responsive)
};

// Optional: require extra stability for "big jumps" (reduces spikes)
static const uint32_t kJumpExtraMs = 400;  // set 0 to disable

static bool isStillClass(int cls) {
  return (cls == 0 /*Sitting*/ || cls == 2 /*Standing*/);
}
static bool isActiveClass(int cls) {
  return (cls == 3 /*Trotting*/ || cls == 4 /*Walking*/ || cls == 1 /*Sniffing*/);
}

// -------------------- State --------------------
static int committedClass = -1;     // what we believe + send (0..4)
static int candidateClass = -1;     // what we are currently considering switching to
static uint32_t candidateSinceMs = 0;

static void sendCommittedIfChanged(int newCommitted) {
  if (newCommitted < 0) return;
  if (newCommitted == committedClass) return;

  committedClass = newCommitted;

  uint16_t cmd = (uint16_t)(committedClass + 1); // 1..5
  Serial.print("[Nicla] ✅ COMMIT -> ");
  Serial.print(labels[committedClass]);
  Serial.print("  (cmd=");
  Serial.print(cmd);
  Serial.println(")");

  bluet.sendCmdU16(cmd);
}

void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println("Init");
  imu.begin();

  /* Init Nicla system and enable battery charging (100mA) */
  nicla::begin();
  nicla::leds.begin();
  nicla::enableCharge(100);
  

  bluet.begin(BLE_NAME);

  Serial.println("Init OK");
}

void loop() {
  bluet.poll();
  imu.read();

  // wait for inference window
  if (!chain(imu.ax, imu.ay, imu.az))
    return;

  const int rawCls = chain.output.classification.idx; // 0..4

  // Debug raw prediction (can comment out later)
  Serial.print("[Nicla] raw=");
  Serial.print(labels[rawCls]);

  // Initialize committed state on first run
  if (committedClass < 0) {
    candidateClass = rawCls;
    candidateSinceMs = millis();
    sendCommittedIfChanged(rawCls);
    delay(5);
    return;
  }

  // If raw matches committed, reset candidate tracking
  if (rawCls == committedClass) {
    candidateClass = committedClass;
    candidateSinceMs = millis();
    Serial.println(" (stable)");
    delay(5);
    return;
  }

  const uint32_t now = millis();

  // If raw changed to a new candidate, restart dwell timer
  if (rawCls != candidateClass) {
    candidateClass = rawCls;
    candidateSinceMs = now;

    Serial.print("  cand=");
    Serial.print(labels[candidateClass]);
    Serial.println(" (new)");
    delay(5);
    return;
  }

  // Same candidate continuing -> check dwell
  uint32_t required = kDwellMs[candidateClass];

  // Optional anti-spike: add extra dwell for "big jumps"
  // Example: from still -> active (or vice-versa) or skipping intermediate states
  if (kJumpExtraMs > 0) {
    const bool stillToActive = isStillClass(committedClass) && isActiveClass(candidateClass);
    const bool activeToStill = isActiveClass(committedClass) && isStillClass(candidateClass);
    const bool bigJump = (abs(candidateClass - committedClass) >= 2);

    if (stillToActive || activeToStill || bigJump) {
      required += kJumpExtraMs;
    }
  }

  const uint32_t elapsed = now - candidateSinceMs;

  Serial.print("  cand=");
  Serial.print(labels[candidateClass]);
  Serial.print("  elapsed=");
  Serial.print(elapsed);
  Serial.print("ms/");
  Serial.print(required);
  Serial.println("ms");

  if (elapsed >= required) {
    // Commit the change (this is the hysteresis "release")
    sendCommittedIfChanged(candidateClass);

    // Reset candidate tracking to the committed state
    candidateClass = committedClass;
    candidateSinceMs = now;
  } 

  delay(5);
}
