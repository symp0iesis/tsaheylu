#pragma once
#include <ArduinoBLE.h>
#define print_log(msg) Serial.println(msg); Serial.flush(); delay(100);

BLEService service("2d0a0000-e0f7-5fc8-b50f-05e267afeb66");
BLEStringCharacteristic characteristicTX("2d0a0001-e0f7-5fc8-b50f-05e267afeb67", BLERead | BLENotify, 56);
BLEByteCharacteristic characteristicRX("2d0a0002-e0f7-5fc8-b50f-05e267afeb68", BLERead | BLEWrite);


class Blue {
  public:

    Blue() {
      lastAdv = 0;
    }

    /**
     * Init
     */
    void begin() {
      print_log("BLE init..");
      
      if (!BLE.begin()) {
        print_log("ERROR");
        begin();
      }

      BLE.setLocalName(BLE_NAME);
      BLE.setAdvertisedService(service);
      service.addCharacteristic(characteristicTX);
      service.addCharacteristic(characteristicRX);
      BLE.addService(service);
      
      characteristicRX.setEventHandler(BLEWritten, [](BLEDevice central, BLECharacteristic characteristic) {
        // run this code when an external device sends data to this board
        // replace with your own, if needed
        const uint8_t value = characteristicRX.value();

        Serial.print("Got value from BLE device: ");
        Serial.println((int) value);
      });

      advertise();
      Serial.println("BLE init OK");
    }

    /**
     * Advertise self to other BLE devices
     */
    void advertise() {
      const size_t now = millis();

      if (now < lastAdv || now > lastAdv + 5000) {
        BLE.advertise();
        lastAdv = now;
      }
    }

    /**
     * Test if another device is connected
     */
    bool connected() {
      return !!BLE.central() && BLE.central().connected();
    }

    /**
     * Send byte to connected device
     */
    void send(String value) {
      characteristicTX.writeValue(value);
    }

  protected:
    size_t lastAdv;
};
